# ChatKu GLOBAL v2

ChatKu versi deployment-ready untuk dipakai banyak orang lewat internet.

## Fitur
- Daftar akun: nama + username + password
- Login aman dengan password hash + JWT
- Cari pengguna berdasarkan username/nama
- Tambah kontak tersimpan di server
- Chat realtime dengan Socket.IO
- Riwayat pesan tersimpan di PostgreSQL
- Owner/Admin dapat melihat user, blokir/buka blokir, dan menghapus user
- Responsive untuk HP

## Deploy paling mudah: Render
1. Buat akun Render dan upload/import folder project ini ke GitHub.
2. Di Render pilih **New > Blueprint** lalu pilih repository.
3. Render membaca `render.yaml` dan membuat Web Service + PostgreSQL.
4. Saat diminta `OWNER_SETUP_KEY`, isi kode rahasia buatanmu sendiri.
5. Deploy.
6. Buka URL `https://...onrender.com`.
7. Daftar dengan username yang sama dengan `OWNER_USERNAME` dan masukkan `OWNER_SETUP_KEY` agar akun menjadi Owner.

### Catatan penting
- Jangan masukkan password, JWT_SECRET, DATABASE_URL, atau OWNER_SETUP_KEY ke file yang di-upload publik.
- `render.yaml` memakai PostgreSQL agar akun/pesan tidak tersimpan hanya di HP.
- URL publik baru ada setelah deployment berhasil. Project ini sendiri tidak otomatis membuat website live dari Termux.

## Jalankan lokal
Buat PostgreSQL sendiri lalu set environment variable sesuai `.env.example`.

Linux/Termux:
```
export DATABASE_URL='postgresql://...'
export JWT_SECRET='rahasia-panjang'
export OWNER_USERNAME='owner'
export OWNER_SETUP_KEY='kode-owner'
npm install
npm start
```
Buka `http://localhost:3000`.
