const express=require('express');
const http=require('http');
const {Server}=require('socket.io');
const bcrypt=require('bcryptjs');
const jwt=require('jsonwebtoken');
const rateLimit=require('express-rate-limit');
const {Pool}=require('pg');

const PORT=process.env.PORT||3000;
const JWT_SECRET=process.env.JWT_SECRET||'CHANGE_THIS_SECRET_IN_PRODUCTION';
const OWNER_USERNAME=(process.env.OWNER_USERNAME||'owner').toLowerCase();
const OWNER_SETUP_KEY=process.env.OWNER_SETUP_KEY||'';
if(process.env.NODE_ENV==='production' && JWT_SECRET==='CHANGE_THIS_SECRET_IN_PRODUCTION') console.warn('WARNING: set JWT_SECRET in production.');
if(!process.env.DATABASE_URL) throw new Error('DATABASE_URL belum diatur.');

const pool=new Pool({connectionString:process.env.DATABASE_URL,ssl:process.env.DATABASE_SSL==='false'?false:{rejectUnauthorized:false}});
const app=express();
const server=http.createServer(app);
const io=new Server(server,{cors:{origin:true,credentials:true}});

app.use(express.json({limit:'32kb'}));
app.use(rateLimit({windowMs:60*1000,max:180,standardHeaders:true,legacyHeaders:false}));
app.use(express.static(__dirname+'/public'));

async function init(){
 await pool.query(`CREATE TABLE IF NOT EXISTS users(
   id BIGSERIAL PRIMARY KEY,
   name VARCHAR(60) NOT NULL,
   username VARCHAR(24) UNIQUE NOT NULL,
   password_hash TEXT NOT NULL,
   role VARCHAR(10) NOT NULL DEFAULT 'user',
   banned BOOLEAN NOT NULL DEFAULT FALSE,
   created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
 );`);
 await pool.query(`CREATE TABLE IF NOT EXISTS contacts(
   user_id BIGINT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
   contact_id BIGINT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
   created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
   PRIMARY KEY(user_id,contact_id)
 );`);
 await pool.query(`CREATE TABLE IF NOT EXISTS messages(
   id BIGSERIAL PRIMARY KEY,
   from_id BIGINT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
   to_id BIGINT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
   text TEXT NOT NULL CHECK(length(text)<=4000),
   created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
 );`);
}
const publicUser=u=>({id:String(u.id),name:u.name,username:u.username,role:u.role,banned:u.banned,created_at:u.created_at});
function tokenFor(u){return jwt.sign({id:String(u.id),username:u.username,role:u.role},JWT_SECRET,{expiresIn:'30d'});}
function auth(req,res,next){
 try{const raw=(req.headers.authorization||'').replace(/^Bearer\s+/i,'');if(!raw)throw 0;req.auth=jwt.verify(raw,JWT_SECRET);next();}
 catch(e){return res.status(401).json({error:'Sesi tidak valid. Silakan login lagi.'});}
}
async function getMe(id){const {rows}=await pool.query('SELECT * FROM users WHERE id=$1',[id]);return rows[0];}
async function active(req,res,next){const u=await getMe(req.auth.id);if(!u)return res.status(401).json({error:'Akun tidak ditemukan'});if(u.banned)return res.status(403).json({error:'Akun kamu diblokir.'});req.user=u;next();}
function cleanUsername(x){return String(x||'').trim().replace(/^@/,'').toLowerCase();}

app.post('/api/register',async(req,res)=>{
 try{
  const name=String(req.body.name||'').trim();const username=cleanUsername(req.body.username);const password=String(req.body.password||'');const ownerKey=String(req.body.ownerKey||'');
  if(name.length<2||name.length>60)return res.status(400).json({error:'Nama 2-60 karakter.'});
  if(!/^[a-z0-9_.-]{3,24}$/.test(username))return res.status(400).json({error:'Username 3-24 karakter: huruf, angka, _, -, .'});
  if(password.length<6)return res.status(400).json({error:'Password minimal 6 karakter.'});
  const exists=await pool.query('SELECT 1 FROM users WHERE username=$1',[username]);if(exists.rowCount)return res.status(409).json({error:'Username sudah dipakai.'});
  let role='user';
  if(username===OWNER_USERNAME){if(!OWNER_SETUP_KEY||ownerKey!==OWNER_SETUP_KEY)return res.status(403).json({error:'Username owner memerlukan kode owner yang benar.'});role='owner';}
  const hash=await bcrypt.hash(password,12);const {rows}=await pool.query('INSERT INTO users(name,username,password_hash,role) VALUES($1,$2,$3,$4) RETURNING *',[name,username,hash,role]);
  res.json({token:tokenFor(rows[0]),user:publicUser(rows[0])});
 }catch(e){console.error(e);res.status(500).json({error:'Gagal membuat akun.'});}
});

app.post('/api/login',async(req,res)=>{
 try{const username=cleanUsername(req.body.username);const password=String(req.body.password||'');const {rows}=await pool.query('SELECT * FROM users WHERE username=$1',[username]);const u=rows[0];if(!u||!(await bcrypt.compare(password,u.password_hash)))return res.status(401).json({error:'Username atau password salah.'});if(u.banned)return res.status(403).json({error:'Akun kamu diblokir.'});res.json({token:tokenFor(u),user:publicUser(u)});}
 catch(e){console.error(e);res.status(500).json({error:'Login gagal.'});}
});

app.get('/api/me',auth,active,(req,res)=>res.json({user:publicUser(req.user)}));
app.get('/api/users',auth,active,async(req,res)=>{try{const q=cleanUsername(req.query.q);const {rows}=await pool.query(`SELECT id,name,username,role,banned,created_at FROM users WHERE id<>$1 AND banned=false AND ($2='' OR username ILIKE '%'||$2||'%' OR name ILIKE '%'||$2||'%') ORDER BY username LIMIT 30`,[req.user.id,q]);res.json(rows.map(publicUser));}catch(e){res.status(500).json({error:'Gagal mencari pengguna.'});}});
app.get('/api/contacts',auth,active,async(req,res)=>{const {rows}=await pool.query(`SELECT u.id,u.name,u.username,u.role,u.banned,u.created_at FROM contacts c JOIN users u ON u.id=c.contact_id WHERE c.user_id=$1 ORDER BY u.name`,[req.user.id]);res.json(rows.map(publicUser));});
app.post('/api/contacts/:username',auth,active,async(req,res)=>{try{const username=cleanUsername(req.params.username);const {rows}=await pool.query('SELECT * FROM users WHERE username=$1 AND banned=false',[username]);const u=rows[0];if(!u)return res.status(404).json({error:'Pengguna tidak ditemukan.'});if(String(u.id)===String(req.user.id))return res.status(400).json({error:'Kamu tidak bisa menambahkan diri sendiri.'});await pool.query('INSERT INTO contacts(user_id,contact_id) VALUES($1,$2) ON CONFLICT DO NOTHING',[req.user.id,u.id]);res.json({user:publicUser(u)});}catch(e){res.status(500).json({error:'Gagal menambah kontak.'});}});

app.get('/api/messages/:username',auth,active,async(req,res)=>{try{const username=cleanUsername(req.params.username);const {rows}=await pool.query(`SELECT m.id,m.text,m.created_at,u.username AS from_username,t.username AS to_username FROM messages m JOIN users u ON u.id=m.from_id JOIN users t ON t.id=m.to_id WHERE (m.from_id=$1 AND m.to_id=(SELECT id FROM users WHERE username=$2)) OR (m.to_id=$1 AND m.from_id=(SELECT id FROM users WHERE username=$2)) ORDER BY m.id ASC LIMIT 500`,[req.user.id,username]);res.json(rows.map(m=>({id:String(m.id),from:m.from_username,to:m.to_username,text:m.text,time:m.created_at})));}catch(e){res.status(500).json({error:'Gagal mengambil pesan.'});}});

app.post('/api/messages',auth,active,async(req,res)=>{try{const to=cleanUsername(req.body.to);const text=String(req.body.text||'').trim();if(!text||text.length>4000)return res.status(400).json({error:'Pesan kosong atau terlalu panjang.'});const {rows}=await pool.query('SELECT * FROM users WHERE username=$1 AND banned=false',[to]);const target=rows[0];if(!target)return res.status(404).json({error:'Pengguna tidak ditemukan.'});const {rows:r}=await pool.query('INSERT INTO messages(from_id,to_id,text) VALUES($1,$2,$3) RETURNING id,created_at',[req.user.id,target.id,text]);const msg={id:String(r[0].id),from:req.user.username,to:target.username,text,time:r[0].created_at};io.to('u:'+target.username).emit('new_message',msg);io.to('u:'+req.user.username).emit('new_message',msg);res.json(msg);}catch(e){console.error(e);res.status(500).json({error:'Gagal mengirim pesan.'});}});

function owner(req,res,next){if(req.user.role!=='owner'&&req.user.role!=='admin')return res.status(403).json({error:'Akses admin ditolak.'});next();}
app.get('/api/admin/users',auth,active,owner,async(req,res)=>{const {rows}=await pool.query('SELECT id,name,username,role,banned,created_at FROM users ORDER BY id DESC LIMIT 200');res.json(rows.map(publicUser));});
app.post('/api/admin/users/:id/ban',auth,active,owner,async(req,res)=>{const id=req.params.id;const {rows}=await pool.query('SELECT * FROM users WHERE id=$1',[id]);const u=rows[0];if(!u)return res.status(404).json({error:'User tidak ditemukan.'});if(u.role==='owner')return res.status(400).json({error:'Owner tidak bisa diblokir.'});await pool.query('UPDATE users SET banned=NOT banned WHERE id=$1',[id]);res.json({ok:true});});
app.delete('/api/admin/users/:id',auth,active,owner,async(req,res)=>{const {rows}=await pool.query('SELECT * FROM users WHERE id=$1',[req.params.id]);const u=rows[0];if(!u)return res.status(404).json({error:'User tidak ditemukan.'});if(u.role==='owner')return res.status(400).json({error:'Owner tidak bisa dihapus.'});await pool.query('DELETE FROM users WHERE id=$1',[req.params.id]);res.json({ok:true});});

io.use((socket,next)=>{try{const token=socket.handshake.auth?.token;socket.user=jwt.verify(token,JWT_SECRET);next();}catch(e){next(new Error('Unauthorized'));}});
io.on('connection',socket=>{socket.join('u:'+socket.user.username);});

app.get('*',(req,res)=>res.sendFile(__dirname+'/public/index.html'));
init().then(()=>server.listen(PORT,'0.0.0.0',()=>console.log('ChatKu GLOBAL berjalan di port '+PORT))).catch(e=>{console.error(e);process.exit(1)});
